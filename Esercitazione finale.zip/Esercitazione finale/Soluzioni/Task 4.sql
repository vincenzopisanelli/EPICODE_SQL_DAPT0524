/* 1) Verificare che i campi definiti come PK siano univoci. In altre parole, scrivi una query per determinare l’unicità 
      dei valori di ciascuna PK (una query per tabella implementata). */

SELECT 
CategoryID
, COUNT(CategoryID)
FROM category
GROUP BY CategoryID
HAVING COUNT(CategoryID) > 1;

SELECT 
ProductID
, COUNT(ProductID)
FROM product
GROUP BY ProductID
HAVING COUNT(ProductID) > 1;

SELECT 
RegionID
, COUNT(RegionID)
FROM region
GROUP BY RegionID
HAVING COUNT(RegionID) > 1;

SELECT 
StateID
, COUNT(StateID)
FROM state
GROUP BY StateID
HAVING COUNT(StateID) > 1;

SELECT 
OrderID
, COUNT(OrderID)
FROM sales
GROUP BY OrderID
HAVING COUNT(OrderID) > 1;

/* 2) Esporre l’elenco delle transazioni indicando nel result set il codice documento, la data, il nome del prodotto, 
      la categoria del prodotto, il nome dello stato, il nome della regione di vendita e un campo booleano valorizzato 
      in base alla condizione che siano passati più di 180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> False). */

SELECT 
OrderID
, OrderDate
, p.ProductName
, c.CategoryName
, st.StateName
, r.RegionName
, CASE 
	  WHEN DATEDIFF('2024-11-11', OrderDate) > 180 THEN 'True'
	  ELSE 'False'
  END AS DayNumber_Since_OrderDate_Greater_Than_180
FROM sales AS sl
INNER JOIN product AS p
ON sl.ProductID = p.ProductID
INNER JOIN category AS c
ON p.CategoryID = c.CategoryID
INNER JOIN state AS st
ON sl.StateID = st.StateID
INNER JOIN region AS r
ON st.RegionID = r.RegionID;

/* 3) Esporre l’elenco dei prodotti che hanno venduto, in totale, una quantità maggiore della media delle vendite realizzate 
      nell’ultimo anno censito. (ogni valore della condizione deve risultare da una query e non deve essere inserito a mano). 
      Nel result set devono comparire solo il codice prodotto e il totale venduto. */

SELECT 
p.ProductID 
, p.ProductName
, SUM(s.OrderQuantity) AS TotaleOrderQuantity
, (SELECT AVG(OrderQuantity) FROM sales WHERE YEAR(OrderDate) = 2024) AS TotalAvgOrderQuantity
FROM product AS p
INNER JOIN sales AS s
ON p.ProductID = s.ProductID
WHERE YEAR(OrderDate) = 2024
GROUP BY p.ProductID, p.ProductName
HAVING SUM(s.OrderQuantity) > (SELECT AVG(OrderQuantity)
							   FROM sales
                               WHERE YEAR(OrderDate) = 2024)
ORDER BY ProductID;   

-- 4) Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno.

SELECT 
p.ProductID
, p.ProductName
, SUM(s.SalesAmount) AS TotalSalesAmount
, YEAR(s.OrderDate) AS Year
FROM product AS p
INNER JOIN sales AS s
ON p.ProductID = s.ProductID
GROUP BY p.ProductID, YEAR(s.OrderDate);

-- 5) Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.

SELECT 
p.ProductID
, p.ProductName
, SUM(sa.SalesAmount) AS TotalSalesAmount
, st.StateName 
, YEAR(sa.OrderDate) AS Year
FROM product AS p
INNER JOIN sales AS sa
ON p.ProductID = sa.ProductID
INNER JOIN state AS st
ON sa.StateID = st.StateID
GROUP BY p.ProductID, YEAR(sa.OrderDate), st.StateID
ORDER BY Year, TotalSalesAmount DESC;

-- 6) Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?

SELECT 
c.CategoryName
, SUM(s.OrderQuantity) AS OrderQuantity
FROM product AS p
INNER JOIN category AS c
ON p.CategoryID = c.CategoryID
LEFT OUTER JOIN sales as s
ON p.ProductID = s.ProductID
GROUP BY c.CategoryID
ORDER BY OrderQuantity DESC
LIMIT 1;

-- 7) Rispondere alla seguente domanda: quali sono i prodotti invenduti? Proponi due approcci risolutivi differenti.

   -- APPROCCIO 1
   
   SELECT 
   ProductID
   , ProductName
   FROM product
   WHERE ProductID NOT IN(SELECT DISTINCT p.ProductID
                          FROM product AS p
                          INNER JOIN sales AS s
                          ON p.ProductID = s.ProductID);
                       
   -- APPROCCIO 2
   
   SELECT
   p.ProductID
   , p.ProductName
   FROM product AS p
   LEFT OUTER JOIN sales AS s
   ON p.ProductID = s.ProductID
   WHERE s.OrderQuantity IS NULL;
   
/* 8) Creare una vista sui prodotti in modo tale da esporre una “versione denormalizzata” delle informazioni utili 
      (codice prodotto, nome prodotto, nome categoria). */

CREATE VIEW vp_vw_dimproduct AS (
SELECT 
ProductID
, ProductName
, c.CategoryName
FROM product AS p
LEFT OUTER JOIN category AS c
ON p.CategoryID = c.CategoryID);

SELECT * FROM vp_vw_dimproduct;

-- 9) Creare una vista per le informazioni geografiche.

CREATE VIEW vp_vw_dimgeografy AS (
SELECT
r.RegionID
, r.RegionName
, s.StateName
, s.StateID
FROM region AS r
INNER JOIN state AS s
ON r.RegionID = s.RegionID);

SELECT * FROM vp_vw_dimgeografy;















   
   
   
   
   
   
   
   
   
   
   



































                            





























